using CsvComparator.Models;
using CsvHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsvComparator
{
    public static class FileReader
    {
        public static string QUARTERLY = "QUARTERLY";
        public static string ADHOC = "ADHOC";

        public static List<string> FetchListOfAccounts(string filePath, string inputType)
        {
            var result = new List<string>();
            if (inputType.Equals(QUARTERLY))
            {
                try
                {
                    result = FetchListOfAccountsInPlf(filePath);
                }
                catch (Exception e)
                {
                    //Couldn't read data for some file - IO error or invalid format maybe? - just skip for now
                }
            } else if (inputType.Equals(ADHOC))
            {
                try
                {
                    result = FetchListOfAccountsInMwb(filePath);
                }
                catch(Exception e)
                {
                    //Couldn't read data for some file - IO error or invalid format maybe? - just skip for now
                    return null;
                }
            }
            return result;

        }
        public static List<string> FetchListOfAccountsInPlf(string filePath)
        {
            string[] lines = System.IO.File.ReadAllLines(filePath);

            //get column index of account so even if layout changes, we know which column is account
            var columnHeaders = lines[0].Split(',').ToList();
            var accountColumn = columnHeaders.IndexOf("FUND CODE");

            //row 0 is headers
            int currentRow = 1;
            List<string> accountsList = new List<string>();

            while (currentRow <= lines.Length - 1)
            {
                var currentDataRow = lines[currentRow].Split(',');
                string currentAccount = currentDataRow[accountColumn];
                if (!currentAccount.Trim().Equals(String.Empty))
                {
                    accountsList.Add(currentAccount);
                }

                currentRow++;
            }
            
            return accountsList.Distinct().ToList();

        }
        public static List<string> FetchListOfAccountsInMwb(string filePath)
        {
            string[] lines = System.IO.File.ReadAllLines(filePath);

            //get column index of account so even if layout changes, we know which column is account
            var columnHeaders = lines[2].Split(',').ToList();
            var accountColumn = columnHeaders.IndexOf("Account");

            //row 0, row 1, and row 3 are useless. row 2 is header so we start at 4
            int currentRow = 4;

            List<string> accountsList = new List<string>();

            while (currentRow <= lines.Length - 1)
            {
                var currentDataRow = lines[currentRow].Split(',');

                string currentAccount = currentDataRow[accountColumn];
                if(!currentAccount.Trim().Equals(String.Empty))
                {
                    accountsList.Add(currentAccount);
                }
                currentRow++;
            }
           
            return accountsList.Distinct().ToList();

        }
        public static List<PrimaryFile> ReadPrimaryFile(string filePath)
        {
            Console.WriteLine("\n-------------------Reading Primary File-------------------\n");
            using (var reader = new StreamReader(filePath))
            {
                using (var csv = new CsvReader(reader))
                {
                    csv.Configuration.IgnoreBlankLines = true;
                    csv.Configuration.RegisterClassMap<PrimaryFileMap>();

                    List<PrimaryFile> records = new List<PrimaryFile>();
                    var isHeader = true;
                    while (csv.Read())
                    {
                        if (isHeader)
                        {
                            csv.ReadHeader();
                            isHeader = false;
                            continue;
                        }

                        if (string.IsNullOrEmpty(csv.GetField(0)))
                        {
                            isHeader = true;
                            continue;
                        }

                        switch (csv.Context.HeaderRecord[0])
                        {
                            case "FUND CODE":
                                records.Add(csv.GetRecord<PrimaryFile>());
                                break;
                            default:
                                throw new InvalidOperationException("Unknown record type.");
                        }
                    }

                    foreach (var record in records)
                    {
                        Console.WriteLine(record);
                    }

                    return records;
                }
            }
        }

        public static List<SecondaryFile> ReadSecondaryFile(string filePath)
        {
            Console.WriteLine("\n-------------------Reading Secondary File-------------------\n");
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader))
            {
                /* var ignoreStrings = new string[] {
                     "CREATION_UNIT_SIZE"
                     ,"SETTLEMENT_CYCLE"
                     ,"NAV"
                     ,"NAV_PER_CREATION_UNIT"
                     ,"NAV_LESS_UNDISTRIBUTED_NET_INCOME"
                     ,"ETF_SHARES_OUTSTANDING"
                     ,"TOTAL_NET_ASSETS"
                 };*/

                var ignoreStrings = new string[] {
                    "SETTLEMENT_CYCLE"
                    ,"NAV"
                    ,"NAV_PER_CREATION_UNIT"
                    ,"NAV_LESS_UNDISTRIBUTED_NET_INCOME"
                    ,"TOTAL_NET_ASSETS"
                };
                var records = new List<SecondaryFile>();
                csv.Configuration.IgnoreBlankLines = true;
                csv.Configuration.MissingFieldFound = null;
                string fundName = null;
                long unit_size = 0;
                long outstanding = 0;
                while (csv.Read())
                {
                    var startValue = csv.GetField(0);
                    if (ignoreStrings.Contains(startValue))
                    {
                        continue;
                    }
                    else if (startValue.Contains("TRADE_DATE"))
                    {
                        fundName = csv.GetField(2);
                    }
                    else if (startValue.Contains("CREATION_UNIT_SIZE"))
                    {
                        unit_size = Convert.ToInt64(csv.GetField(1));
                    }
                    else if (startValue.Contains("ETF_SHARES_OUTSTANDING"))
                    {
                        outstanding = Convert.ToInt64(csv.GetField(1));
                    }
                    else if (startValue.Contains("CUSIP"))
                    {
                        csv.ReadHeader();
                    }
                    else
                    {
                        var record = csv.GetRecord<SecondaryFile>();
                        record.FUNDCODE = fundName.ToUpper();
                        int divisor = Convert.ToInt16(Math.Round(Convert.ToDouble(outstanding) / Convert.ToDouble(unit_size)));
                        record.DIVISOR = divisor;
                        records.Add(record);
                    }

                }
                foreach (var record in records)
                {
                    Console.WriteLine(record);
                }
                return records;

            }

        }

        public static List<PrimaryFile> ReadMWBFile(string filePath)
        {
            Console.WriteLine("\n-------------------Reading TestPLF File-------------------\n");
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader))
            {
                var ignoreStrings = new string[] {
                    "Manager Workbench - PMG_MWB_1"
                    ,"ETFs \\ Positions"
                };
                var records = new List<PrimaryFile>();
                csv.Configuration.IgnoreBlankLines = true;
                csv.Configuration.MissingFieldFound = null;

                for (var i = 0; i < 2; i++)
                {
                    csv.Read();
                }
                while (csv.Read())
                {
                    var startValue = csv.GetField(0);
                    if (ignoreStrings.Contains(startValue))
                    {
                        continue;
                    }
                    else if (startValue.Contains("Security"))
                    {
                        csv.ReadHeader();
                    }
                    else
                    {                 
                        var record = csv.GetRecord<PrimaryFile>();
                        record.ACCOUNT = csv.GetField(5);
                        record.ISIN = csv.GetField(8);
                        record.CUSIP = csv.GetField(9);
                        record.SEDOL = csv.GetField(11);
                        int basketShares;
                        if(!int.TryParse(csv.GetField(14), out basketShares))
                        {
                            basketShares = 0;
                        }
                        record.BASKETSHARES = basketShares;
                        record.CURRENCYCODE = csv.GetField(17);
                        record.CIL = csv.GetField(18);
                        record.TRADECOUNTRY = csv.GetField(20);

                        if (!string.IsNullOrEmpty(record.ACCOUNT))
                            records.Add(record);
                    }
                }
                foreach (var record in records)
                {
                    Console.WriteLine(record);
                }
                return records;

            }
        }
    }
}
