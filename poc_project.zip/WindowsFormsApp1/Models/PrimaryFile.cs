using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CsvComparator.Models
{
    public class PrimaryFile
    {
        public string ACCOUNT { get; set; }
        public string ISIN { get; set; }
        public string CUSIP { get; set; }
        public string SEDOL { get; set; }
        public int? BASKETSHARES { get; set; }
        //public string BASKET_SHARES { get; set; }
        public string CURRENCYCODE { get; set; }
        public string CIL { get; set; }
        public string TRADECOUNTRY { get; set; }
        

        public override string ToString()
        {
            var text = string.Join
            (
                ",",
                typeof(PrimaryFile)
                    .GetProperties(BindingFlags.Instance | BindingFlags.Public)
                    .Select
                    (
                        prop => prop.GetValue(this)==null?"": prop.GetValue(this).ToString()
                    )
            );
            return text;
        }
    }

    public class PrimaryFileMap : ClassMap<PrimaryFile>
    {
        public PrimaryFileMap()
        {
            Map(m => m.ACCOUNT).Name("FUND CODE");
            Map(m => m.ISIN).Name("ISIN");
            Map(m => m.CUSIP).Name("CUSIP");
            Map(m => m.SEDOL).Name("SEDOL");
            Map(m => m.BASKETSHARES).Name("BASKET SHARES");
            Map(m => m.CURRENCYCODE).Name("CURRENCY CODE");
            Map(m => m.CIL).Name("CIL");
            Map(m => m.TRADECOUNTRY).Name("TRADE COUNTRY");
        }
    }
}
