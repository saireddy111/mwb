using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MPDETF.Models
{
    public class FileViewRow
    {
        public string _filePath;

        public bool _hasError;

        public string Accounts { get; set; }

        public string FileName
        {
            get {
                return Path.GetFileName(_filePath);
            }
        }

        public string CreatedBy { get; set; }

        public DateTime CreatedTime { get; set; }

        
    }
}
