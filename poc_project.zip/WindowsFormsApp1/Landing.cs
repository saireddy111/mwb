﻿using CsvComparator;
using CsvComparator.Models;
using MPDETF.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Landing : Form
    {
        private bool QuarterlyGridIsReady = false;
        private bool AdhocGridIsReady = false;
              
        private System.IO.FileSystemWatcher m_Watcher_qtr;
        private System.IO.FileSystemWatcher m_Watcher_mwb;

        public Landing()
        {
            InitializeComponent();                      
        }

        private List<string> GetFilesFromDirectory(string path, string pattern)
        {
            var result = new List<string>();
            try
            {
                result = Directory.GetFiles(path, pattern).ToList<string>();
            }
            catch (Exception e)
            {
                MessageBox.Show("Unable to Fetch files form " + path + ". " + e.Message, "Error retrieving files");
            }
            return result;
        }

        private List<FileViewRow> GetQuarterlyGridRows()
        {
            List<FileViewRow> result = GetInputGridRows(ConfigurationManager.AppSettings.Get("QuarterlyFilePath"), ConfigurationManager.AppSettings.Get("QuarterlyFileFormat"), FileReader.QUARTERLY);
            return result;
        }

        private List<FileViewRow> GetAdhocGridRows()
        {
            List<FileViewRow> result = GetInputGridRows(ConfigurationManager.AppSettings.Get("AdHocFilePath"), ConfigurationManager.AppSettings.Get("AdHocFileFormat"), FileReader.ADHOC);
            return result;
        }

        private List<FileViewRow> GetInputGridRows(string path, string pattern, string inputType)
        {
            var files = GetFilesFromDirectory(path, pattern);
            var result = files.Select(f => ParseFileForGridEntry(f, inputType)).ToList();
            if (result.Count==0)
            {
                FileViewRow current = new FileViewRow
                {
                    _filePath = "File Not Found",
                    Accounts = "-",
                    _hasError = true,
                    CreatedBy = "-",
                    CreatedTime = new DateTime()
                };
                result.Add(current);
            }
            return result;
        }

        private string GetUserName(string filename)
        {
            var owner = File.GetAccessControl(filename).GetOwner(typeof(System.Security.Principal.NTAccount)).ToString();
            return owner.Split('\\')[1].ToString().ToUpper();
        }

        private FileViewRow ParseFileForGridEntry(string filename, string inputType)
        {
            var fetchedAccounts = FileReader.FetchListOfAccounts(filename, inputType);
            bool hasError = false;
            string listOfAccounts = "";
            if (fetchedAccounts == null)
            {
                //There was an error
                hasError = true;
            }
            else
            {
                listOfAccounts = String.Join(",", fetchedAccounts);
            }

            FileViewRow current = new FileViewRow
            {
                _filePath = filename,
                Accounts = listOfAccounts,
                _hasError = hasError,
                CreatedBy = GetUserName(filename),
                CreatedTime = File.GetCreationTime(filename)
            };
            return current;
        }


       /* private void Adhoc_Btn_Approved_Click(object sender, EventArgs e)
        {

            string fileName = "Ad-hocFile.csv";
            string sourcePath = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\import\adhoc";
            string targetPath = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\export\adhoc\archive\approved";

            string targetPath2 = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\approved\archive";
            string sourceFile = System.IO.Path.Combine(sourcePath, fileName);
            string destFile = System.IO.Path.Combine(targetPath, fileName);
            string destFile2 = System.IO.Path.Combine(targetPath2, fileName);

            System.IO.Directory.CreateDirectory(targetPath);
            System.IO.Directory.CreateDirectory(targetPath2);

            File.Copy(sourceFile, destFile, true);
            File.Copy(sourceFile, destFile2, true);
            MessageBox.Show("File copied to the Approved Folder.", "Notification");
            UpdateResultsGrid(null);
            label1.Text = "Ad-Hoc file moved to the Approved Folder";
        }

        private void Adhoc_Reject_Btn_Click(object sender, EventArgs e)
        {
            string fileName = "Ad-hocFile.csv";
            string sourcePath = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\import\adhoc";
            string targetPath = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\export\adhoc\archive\rejected";
            string sourceFile = System.IO.Path.Combine(sourcePath, fileName);
            string destFile = System.IO.Path.Combine(targetPath, fileName);

            System.IO.Directory.CreateDirectory(targetPath);

            File.Copy(sourceFile, destFile, true);
            MessageBox.Show("File copied to the Rejected Folder.", "Notification");
            UpdateResultsGrid(null);
            label1.Text = "Ad-Hoc file moved to the Rejected Folder";
        }

        private void Quarterly_Btn_Approved_Click(object sender, EventArgs e)
        {
            string fileName = "QuarterlyFile.csv";
            string sourcePath = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\Scottqtrfile";
            string targetPath = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\export\adhoc\archive\approved";

            string targetPath2 = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\approved\archive";
            string sourceFile = System.IO.Path.Combine(sourcePath, fileName);
            string destFile = System.IO.Path.Combine(targetPath, fileName);
            string destFile2 = System.IO.Path.Combine(targetPath2, fileName);

            System.IO.Directory.CreateDirectory(targetPath);
            System.IO.Directory.CreateDirectory(targetPath2);

            File.Copy(sourceFile, destFile, true);
            File.Copy(sourceFile, destFile2, true);
            MessageBox.Show("File copied to the Approved Folder.", "Notification");
            UpdateResultsGrid(null);
            label1.Text = "Quarterly file moved to the Approved Folder";
        }
        */
        private void Quarterly_Btn_Rejected_Click(object sender, EventArgs e)
        {

            string fileName = "QuarterlyFile.csv";
            string sourcePath = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\Scottqtrfile";
            string targetPath = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\export\adhoc\archive\rejected";
            string sourceFile = System.IO.Path.Combine(sourcePath, fileName);
            string destFile = System.IO.Path.Combine(targetPath, fileName);

            System.IO.Directory.CreateDirectory(targetPath);

            File.Copy(sourceFile, destFile, true);
            MessageBox.Show("File copied to the Rejected Folder.", "Notification");
            UpdateResultsGrid(null);
            label1.Text = "Quarterly file moved to the Rejected Folder";
        }

        private void RefreshInputFileGrids()
        {
            dgvQuarterlyFiles.DataSource = GetQuarterlyGridRows();
            dgvQuarterlyFiles.ClearSelection();
            foreach (DataGridViewColumn c in dgvQuarterlyFiles.Columns)
            {
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
            QuarterlyGridIsReady = true;
            //Parse through it to find errenous rows
            foreach (DataGridViewRow r in dgvQuarterlyFiles.Rows)
            {
                if (((FileViewRow)r.DataBoundItem)._hasError)
                {
                    r.DefaultCellStyle.BackColor = Color.PaleVioletRed;
                    r.DefaultCellStyle.ForeColor = Color.White;
                }
            }

            dgvAdhoc.DataSource = GetAdhocGridRows();
            dgvAdhoc.ClearSelection();
            foreach (DataGridViewColumn c in dgvAdhoc.Columns)
            {
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
            AdhocGridIsReady = true;
            foreach (DataGridViewRow r in dgvAdhoc.Rows)
            {
                if (((FileViewRow)r.DataBoundItem)._hasError)
                {
                    r.DefaultCellStyle.BackColor = Color.PaleVioletRed;
                    r.DefaultCellStyle.ForeColor = Color.White;
                }
            }

            lblCurrentFile.Text = "";
            UpdateResultsGrid(null);
        }

        public void UpdateResultsGrid(List<CsvComparator.Models.PrimaryFile> result)
        {
            dgvPlfTrades.DataSource = result;
            if (dgvPlfTrades.Columns.Count > 0)
            {
                foreach (DataGridViewColumn c in dgvPlfTrades.Columns)
                {
                    c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                }
                dgvPlfTrades.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }
        private void LoadSelectedFile(DataGridView dgv, FileViewRow file, int rowIndex, string source)
        {
            UpdateResultsGrid(null);
            lblCurrentFile.Text = "";

            List<CsvComparator.Models.PrimaryFile> result = new List<CsvComparator.Models.PrimaryFile>();
            try
            {
                if (source.Equals(FileReader.QUARTERLY))
                {
                    result = FileReader.ReadPrimaryFile(file._filePath);
                }
                else if (source.Equals(FileReader.ADHOC))
                {
                    result = FileReader.ReadMWBFile(file._filePath);
                }
                UpdateResultsGrid(result);
                lblCurrentFile.Text = file.FileName;

            }
            catch (IOException e)
            {
                MessageBox.Show("Error reading file: " + e.Message, "Error Parsing File");
                if (rowIndex <= dgv.Rows.Count)
                {
                    DataGridViewRow currentRow = dgv.Rows[rowIndex];
                    currentRow.DefaultCellStyle.BackColor = Color.PaleVioletRed;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Unable to load file. Invalid Format! " + e.Message, "Error Parsing File");
                if (rowIndex <= dgv.Rows.Count)
                {
                    DataGridViewRow currentRow = dgv.Rows[rowIndex];
                    currentRow.DefaultCellStyle.BackColor = Color.PaleVioletRed;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            m_Watcher_qtr = new System.IO.FileSystemWatcher();
            m_Watcher_qtr.Filter = "*.csv";
            m_Watcher_qtr.Path = ConfigurationManager.AppSettings.Get("QuarterlyFilePath") + "\\";
            m_Watcher_qtr.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
                                     | NotifyFilters.FileName | NotifyFilters.DirectoryName;
            m_Watcher_qtr.Changed += new FileSystemEventHandler(OnChanged);
            m_Watcher_qtr.Created += new FileSystemEventHandler(OnChanged);
            m_Watcher_qtr.Deleted += new FileSystemEventHandler(OnChanged);
            m_Watcher_qtr.Renamed += new RenamedEventHandler(OnRenamed);
            m_Watcher_qtr.EnableRaisingEvents = true;

            m_Watcher_mwb = new System.IO.FileSystemWatcher();
            m_Watcher_mwb.Filter = "*.csv";
            m_Watcher_mwb.Path = ConfigurationManager.AppSettings.Get("AdHocFilePath") + "\\";
            m_Watcher_mwb.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
                                     | NotifyFilters.FileName | NotifyFilters.DirectoryName;
            m_Watcher_mwb.Changed += new FileSystemEventHandler(OnChanged);
            m_Watcher_mwb.Created += new FileSystemEventHandler(OnChanged);
            m_Watcher_mwb.Deleted += new FileSystemEventHandler(OnChanged);
            m_Watcher_mwb.Renamed += new RenamedEventHandler(OnRenamed);
            m_Watcher_mwb.EnableRaisingEvents = true;

            RefreshInputFileGrids();
        }

        private void OnChanged(object sender, FileSystemEventArgs e)
        {            
            if (InvokeRequired)
            {
                this.Invoke(new MethodInvoker(delegate
                {
                    MessageBox.Show("File(s) are modified by another process", "Notification");
                    RefreshInputFileGrids();
                }));
            }
        }

        private void OnRenamed(object sender, RenamedEventArgs e)
        {           
            if (InvokeRequired)
            {
                this.Invoke(new MethodInvoker(delegate
                {
                    MessageBox.Show("File(s) are modified by another process", "Notification");
                    RefreshInputFileGrids();
                }));
            }                
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshInputFileGrids();
        }

        private void dgvQuarterlyFiles_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            dgvAdhoc.ClearSelection();
            UpdateResultsGrid(null);
            lblCurrentFile.Text = "";
        }

        private void dgvAdhoc_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            dgvQuarterlyFiles.ClearSelection();
            UpdateResultsGrid(null);
            lblCurrentFile.Text = "";
        }

        private void dgvQuarterlyFiles_MouseClick(object sender, MouseEventArgs e)
        {
            if (dgvQuarterlyFiles.CurrentRow != null)
            {
                FileViewRow currentRow = (FileViewRow)dgvQuarterlyFiles.CurrentRow.DataBoundItem;
                int selectedRowIndex = dgvQuarterlyFiles.CurrentRow.Index;

                if (currentRow != null)
                {
                    LoadSelectedFile(dgvQuarterlyFiles, currentRow, selectedRowIndex, FileReader.QUARTERLY);
                }
            }
        }

        private void dgvAdhoc_Click(object sender, EventArgs e)
        {
            if (dgvAdhoc.CurrentRow != null)
            {
                FileViewRow currentRow = (FileViewRow)dgvAdhoc.CurrentRow.DataBoundItem;
                int selectedRowIndex = dgvAdhoc.CurrentRow.Index;

                if (currentRow != null)
                {
                    LoadSelectedFile(dgvAdhoc, currentRow, selectedRowIndex, FileReader.ADHOC);
                }
            }

        }

        private void BtnApprove_Click(object sender, EventArgs e)
        {

        }

        private void BtnReject_Click(object sender, EventArgs e)
        {
            
            Int32 rowCount = dgvPlfTrades.Rows.Count;
            if (rowCount==0)
            {
                MessageBox.Show("Please select atleast one file.","Notification");
            }
            else
            {
                FileViewRow currentRow = null;
                if (dgvQuarterlyFiles.SelectedRows.Count>0)
                {
                    currentRow= (FileViewRow)dgvQuarterlyFiles.CurrentRow.DataBoundItem;
                }
                else
                {
                    currentRow = (FileViewRow)dgvAdhoc.CurrentRow.DataBoundItem;
                }
                string fileName = currentRow.FileName;               
                string targetPath = @"\\tc230\FTP\Investments\Equity\ETF\QUAL\TROW\rejected";
                               
                string destFile = System.IO.Path.Combine(targetPath, fileName);

                System.IO.Directory.CreateDirectory(targetPath);

                //File.Move(currentRow._filePath, destFile);
                File.Copy(currentRow._filePath, destFile,true);

                MessageBox.Show("File copied to the Rejected Folder.", "Notification");
                RefreshInputFileGrids();
            }

        }
    }
}
